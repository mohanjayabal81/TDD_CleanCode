package com.c.refactoring.lock;

public class Constants {

    public static final String LOCK_TEXT = "Locked by @@USER@@";

}
