package com.c.refactoring.menuexamples;

public class Constants {

    public static final String READ = "READ";
    public static final String WRITE = "WRITE";

}
