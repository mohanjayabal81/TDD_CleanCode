package com.b.simple.design.business.text;

public class TextHelper {

	public String swapLastTwoCharacters(String str) {
		return null;
	}

	public String truncateAInFirst2Positions(String str) {
		return null;
	}
}
